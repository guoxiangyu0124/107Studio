﻿<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<?php
    echo "管理员登陆成功！";
    echo "<br/><a href='login.php'>返回登陆</a>";
?>
